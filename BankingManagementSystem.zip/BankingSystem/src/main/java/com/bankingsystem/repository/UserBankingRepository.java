package com.bankingsystem.repository;

import com.bankingsystem.domain.UserBanking;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserBankingRepository extends JpaRepository<UserBanking,Long> {
	
	@Query(value = "select * from userbanking where userid=?",nativeQuery = true)
	UserBanking findByUserId(Long id);	
	
//	@Query(value = "insert into userbanking values(?,?,?,?,?,?)",nativeQuery = true)
//	UserBanking insertUserBanking(String fullname,Date birthday,String address,Long nationalId,int phone,String email);
	
}
