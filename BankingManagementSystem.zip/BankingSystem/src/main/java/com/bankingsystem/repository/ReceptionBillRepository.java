package com.bankingsystem.repository;

import com.bankingsystem.domain.AccountUser;
import com.bankingsystem.domain.ReceptionBill;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReceptionBillRepository extends JpaRepository<ReceptionBill,Long> {
	
	List<ReceptionBill> findByAccountUser(AccountUser accountUser);
}
