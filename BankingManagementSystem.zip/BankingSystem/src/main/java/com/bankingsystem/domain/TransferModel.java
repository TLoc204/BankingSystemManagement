package com.bankingsystem.domain;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//@Data
//@Getter
//@Setter
public class TransferModel {
	private String srcAccount;
	private String desAccount;
	private Long amount;
	public TransferModel(String srcAccount, String desAccount, Long amount) {
		super();
		this.srcAccount = srcAccount;
		this.desAccount = desAccount;
		this.amount = amount;
	}
	public TransferModel() {
		
	}
	public String getSrcAccount() {
		return srcAccount;
	}
	public void setSrcAccount(String srcAccount) {
		this.srcAccount = srcAccount;
	}
	public String getDesAccount() {
		return desAccount;
	}
	public void setDesAccount(String desAccount) {
		this.desAccount = desAccount;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	
	
	
}
