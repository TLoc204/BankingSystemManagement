package com.bankingsystem.domain;

import lombok.*;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "accountuser")
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
public class AccountUser {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="accountnumber")
    private Long accountNumber;
    private Long balance;
    private String status;

    @OneToMany(cascade = CascadeType.ALL,mappedBy = "accountUser")
    private List<ReceptionBill> receptionBills;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "accountUser")
    private Login login;

	public AccountUser(Long accountNumber, Long balance, String status, List<ReceptionBill> receptionBills,
			Login login) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.status = status;
		this.receptionBills = receptionBills;
		this.login = login;
	}
	
	public AccountUser() {
	
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getBalance() {
		return balance;
	}

	public void setBalance(Long balance) {
		this.balance = balance;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<ReceptionBill> getReceptionBills() {
		return receptionBills;
	}

	public void setReceptionBills(List<ReceptionBill> receptionBills) {
		this.receptionBills = receptionBills;
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}
	
}
