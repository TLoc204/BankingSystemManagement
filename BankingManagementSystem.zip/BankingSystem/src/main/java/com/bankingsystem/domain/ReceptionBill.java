package com.bankingsystem.domain;

import lombok.*;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
@Table(name = "receptionbill")
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReceptionBill {
    @Id
    @GeneratedValue
    @Column(name = "billno")
    private Long billNo;
    private String status;
    private String action;
    @Column(name = "transactiondate")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date transactionDate;
    private Long balance;
    @Column(name="srcaccount")
    private String srcAccount;
    @Column(name = "desaccount")
    private String desAccount;

    @ManyToOne
    @JoinColumn(name = "accountnumber")
    private AccountUser accountUser;
}
