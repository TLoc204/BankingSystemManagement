package com.bankingsystem.domain;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name="login")
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Login {
    @Id
    private String username;
    @Column
    private String password;
    @Column
    private String role;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="userid")
    private UserBanking userBanking;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="accountnumber")
    private AccountUser accountUser;
}
