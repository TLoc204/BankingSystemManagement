package com.bankingsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.bankingsystem.domain.AccountUser;
import com.bankingsystem.domain.Login;
import com.bankingsystem.domain.ReceptionBill;
import com.bankingsystem.repository.AccountUserRepository;
import com.bankingsystem.repository.LoginBankingRepository;
import com.bankingsystem.repository.ReceptionBillRepository;

@Controller
public class TransactionController {
	
	@Autowired
	private ReceptionBillRepository receptionBillRepository;
	
	@Autowired
	private AccountUserRepository accountUserRepository;
	
	@GetMapping("/transaction/{accountNumber}")
	public String transaction(Model model, @PathVariable Long accountNumber) {
		AccountUser a=accountUserRepository.findByAccountNumber(accountNumber);
		List<ReceptionBill> listBill=receptionBillRepository.findByAccountUser(a);
		model.addAttribute("accountNumber", a.getAccountNumber());
		model.addAttribute("listBill",listBill);
		return "userPages/transactionbill";
	}
}
