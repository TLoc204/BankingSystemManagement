package com.bankingsystem.controller;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bankingsystem.domain.AccountUser;
import com.bankingsystem.domain.ReceptionBill;
import com.bankingsystem.domain.TransferModel;
import com.bankingsystem.repository.AccountUserRepository;

@Controller
public class TransferController {
	
	@Autowired
	private AccountUserRepository accountUserRepository;
	
	@GetMapping("/transfer/{accountNumber}")
	public String transfer(@PathVariable Long accountNumber,Model model) {
		AccountUser au=accountUserRepository.findByAccountNumber(accountNumber);
		TransferModel tm=new TransferModel();
		model.addAttribute("detailTransfer", au);
		model.addAttribute("transferModel", tm);
		return "userPages/transfermoney";
	}
	
	@PostMapping("/doTransfer")
	public String doTransfer(@ModelAttribute("transferModel") TransferModel tm,@ModelAttribute("detailTransfer") AccountUser a) {
		AccountUser srcAccount=accountUserRepository.findByAccountNumber(a.getAccountNumber());
		AccountUser desAccount=accountUserRepository.findByAccountNumber(Long.parseLong(tm.getDesAccount()));
		
		List<ReceptionBill> billSrc=new LinkedList<>();
		ReceptionBill recp=new ReceptionBill();
		//SRC information 
		recp.setSrcAccount(String.valueOf(a.getAccountNumber()));
		recp.setDesAccount(tm.getDesAccount());
		recp.setStatus("SUCCESSFUL");
		recp.setTransactionDate(new Date());
		recp.setAction("TRANSFER");
		recp.setBalance(tm.getAmount());
		
		Long total=srcAccount.getBalance()-tm.getAmount();
		srcAccount.setBalance(total);
		recp.setAccountUser(srcAccount);
		billSrc.add(recp);
		srcAccount.setReceptionBills(billSrc);
		accountUserRepository.save(srcAccount);
		
		//DES Information
		List<ReceptionBill> billDes=new LinkedList<>();
		ReceptionBill recp1=new ReceptionBill();
		recp1.setSrcAccount(String.valueOf(a.getAccountNumber()));
		recp1.setDesAccount(tm.getDesAccount());
		recp1.setStatus("SUCCESSFUL");
		recp1.setTransactionDate(new Date());
		recp1.setAction("TRANSFER");
		recp1.setBalance(tm.getAmount());
		
		Long t=desAccount.getBalance()+tm.getAmount();
		desAccount.setBalance(t);
		recp1.setAccountUser(desAccount);
		billDes.add(recp1);
		desAccount.setReceptionBills(billDes);
		System.out.println("HERE");
		accountUserRepository.save(desAccount);
		
		
		
		return "redirect:/transfer/"+a.getAccountNumber();
	}
}
