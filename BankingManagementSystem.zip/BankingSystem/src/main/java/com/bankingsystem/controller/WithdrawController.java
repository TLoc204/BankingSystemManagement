package com.bankingsystem.controller;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bankingsystem.domain.AccountUser;
import com.bankingsystem.domain.ReceptionBill;
import com.bankingsystem.repository.AccountUserRepository;

@Controller
public class WithdrawController {
	
	@Autowired
	private AccountUserRepository accountUserRepository;
	
	@GetMapping("/withdraw/{accountNumber}")
	public String withdraw(@PathVariable Long accountNumber,Model model) {
		AccountUser ac=accountUserRepository.findByAccountNumber(accountNumber);
		model.addAttribute("detailWithdraw", ac);
		
		return "userPages/withdraw";
	}
	
	@PostMapping("/doWithdraw")
	public String doWithdraw(@ModelAttribute("detailWithdraw") AccountUser a) {
		AccountUser ac=accountUserRepository.findByAccountNumber(a.getAccountNumber());
		List<ReceptionBill> listBill=new LinkedList<>();
		ReceptionBill recp=new ReceptionBill();
		
		recp.setAction("WITHDRAW");
		recp.setBalance(a.getBalance());
		recp.setStatus("SUCCESSFUL");
		Date nowDate=new Date();
		recp.setTransactionDate(nowDate);
		recp.setSrcAccount(String.valueOf(a.getAccountNumber()));
		recp.setDesAccount("Other");
		
		Long total=ac.getBalance()-a.getBalance();
		ac.setBalance(total);
		recp.setAccountUser(ac);
		listBill.add(recp);
		ac.setReceptionBills(listBill);
		
		accountUserRepository.save(ac);
		return "redirect:/withdraw/"+a.getAccountNumber();
	}

}
